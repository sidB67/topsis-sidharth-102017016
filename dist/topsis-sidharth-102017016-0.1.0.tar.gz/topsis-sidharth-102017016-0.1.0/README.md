## Topsis-Sidharth-102017016
### It calculates topsis for a given data in csv file.

### Installation
## pip install topsis-sidharth-102017016



## License
### © 2023 Sidharth Bahl

### This repository is licensed under the MIT license. See LICENSE for details.